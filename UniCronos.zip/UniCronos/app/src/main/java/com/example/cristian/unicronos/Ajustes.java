package com.example.cristian.unicronos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Ajustes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);
        buttonCerrarsesion();

    }

    private void buttonCerrarsesion() {
        Button botonCerrarsesion = (Button) findViewById(R.id.cerrarsesion);
        botonCerrarsesion.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent login = new Intent(getApplicationContext(), Login.class);
                startActivity(login);
                finish();
            }
        });
    }

}