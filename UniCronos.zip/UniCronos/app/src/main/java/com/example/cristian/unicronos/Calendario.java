package com.example.cristian.unicronos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Calendario extends AppCompatActivity {
    String usuario, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usuario = getIntent().getStringExtra("nombre_usuario");
        mail = getIntent().getStringExtra("email_usuario");
        setContentView(R.layout.activity_calendario);
    }

    @Override
    public void onBackPressed() {
        Intent menu = new Intent(getApplicationContext(), Menu.class);
        menu.putExtra("nombre_usuario", usuario);
        menu.putExtra("email_usuario", mail);
        startActivity(menu);
        finish();
    }
}
