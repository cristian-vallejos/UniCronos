package com.example.cristian.unicronos;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Notas extends AppCompatActivity {
    TextView grade_1;
    Button button_1;
    Button grades;

    String line;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notas);
        buttonAddCourse();
        buttonViewCourse();
    }

    @Override
    protected void onResume(){
        super.onResume();

        try{
            grade_1 = (TextView) findViewById(R.id.grade_1);
            button_1 = (Button) findViewById(R.id.button_1);

            // Open the file that is the first
            // command line parameter
            FileInputStream fstream = new FileInputStream("YerkoCuzmar.txt");
            // Get the object of DataInputStream
            DataInputStream in = new DataInputStream(fstream);
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String ramo, color, titulo1, nota1, pond1;
            while ((line = br.readLine()) != null) {
                ramo = line.split("/")[0];
                color = line.split("/")[1].split("!")[0];
                titulo1 = line.split("/")[1].split("!")[1].split("%")[0];
                nota1 = line.split("/")[1].split("!")[1].split("%")[1].split("&")[0];
                pond1 = line.split("/")[1].split("!")[1].split("%")[1].split("&")[1];
            }
            in.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void buttonAddCourse() {
        Button botonAddCourse = (Button) findViewById(R.id.add_course);
        botonAddCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent add_course = new Intent(getApplicationContext(), CourseAdd.class);
                startActivity(add_course);
                finish();
            }
        });
    }

    private void buttonViewCourse() {
        Button botonViewCourse = (Button) findViewById(R.id.button_1);
        botonViewCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                grades = (Button) findViewById(R.id.notas);
                grades.setVisibility(View.VISIBLE);
            }
        });
    }
}
