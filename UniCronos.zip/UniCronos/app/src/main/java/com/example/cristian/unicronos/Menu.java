package com.example.cristian.unicronos;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.os.Handler;

public class Menu extends AppCompatActivity {
    String usuario, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usuario = getIntent().getStringExtra("nombre_usuario");
        mail = getIntent().getStringExtra("email_usuario");
        setTitle(usuario);
        setContentView(R.layout.activity_menu);

        buttonHorario();
        buttonCalendario();
        buttonNotas();
        buttonAjustes();
    }

    private void buttonHorario() {
        Button botonHorario = (Button) findViewById(R.id.horario);
        botonHorario.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent horario = new Intent(getApplicationContext(), Horario.class);
                horario.putExtra("nombre_usuario", usuario);
                horario.putExtra("email_usuario", mail);
                startActivity(horario);
                finish();
            }
        });
    }

    private void buttonCalendario() {
        Button botonCalendario = (Button) findViewById(R.id.calendario);
        botonCalendario.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent calendario = new Intent(getApplicationContext(), Calendario.class);
                calendario.putExtra("nombre_usuario", usuario);
                calendario.putExtra("email_usuario", mail);
                startActivity(calendario);
                finish();
            }
        });
    }

    private void buttonNotas() {
        Button botonNotas = (Button) findViewById(R.id.notas);
        botonNotas.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent notas = new Intent(getApplicationContext(), Notas.class);
                notas.putExtra("nombre_usuario", usuario);
                notas.putExtra("email_usuario", mail);
                startActivity(notas);
                finish();
            }
        });
    }

    private void buttonAjustes() {
        Button botonAjustes = (Button) findViewById(R.id.ajustes);
        botonAjustes.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent ajustes = new Intent(getApplicationContext(), Ajustes.class);
                ajustes.putExtra("nombre_usuario", usuario);
                ajustes.putExtra("email_usuario", mail);
                startActivity(ajustes);
                finish();
            }
        });
    }

    private Boolean exit = false;
    @Override
    public void onBackPressed() {
        if (exit) {
            Intent homeIntent = new Intent(Intent.ACTION_MAIN);
            homeIntent.addCategory( Intent.CATEGORY_HOME );
            homeIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(homeIntent);
            // finish activity
        } else {
            Toast.makeText(this, "Presiona otra vez para salir",
                    Toast.LENGTH_SHORT).show();
            exit = true;
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    exit = false;
                }
            }, 3 * 1000);

        }
    }
}
