package com.example.cristian.unicronos;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class CourseAdd extends AppCompatActivity {
    ArrayList<Button> colors = new ArrayList<>();
    String background;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_add);
        buttonSetUpCourse();

        // Tonalides de ROJO
        colors.add((Button) findViewById(R.id.red1)); colors.add((Button) findViewById(R.id.red2));
        colors.add((Button) findViewById(R.id.red3)); colors.add((Button) findViewById(R.id.red4));

        // Tonalides de ROSA
        colors.add((Button) findViewById(R.id.pink1)); colors.add((Button) findViewById(R.id.pink2));
        colors.add((Button) findViewById(R.id.pink3)); colors.add((Button) findViewById(R.id.pink4));

        // Tonalides de AZUL
        colors.add((Button) findViewById(R.id.blue1)); colors.add((Button) findViewById(R.id.blue2));
        colors.add((Button) findViewById(R.id.blue3)); colors.add((Button) findViewById(R.id.blue4));

        // Tonalides de CELESTE
        colors.add((Button) findViewById(R.id.skyblue1)); colors.add((Button) findViewById(R.id.skyblue2));
        colors.add((Button) findViewById(R.id.skyblue3)); colors.add((Button) findViewById(R.id.skyblue4));

        // Tonalides de VERDE
        colors.add((Button) findViewById(R.id.green1)); colors.add((Button) findViewById(R.id.green2));
        colors.add((Button) findViewById(R.id.green3)); colors.add((Button) findViewById(R.id.green4));

        // Tonalides de NARANJO
        colors.add((Button) findViewById(R.id.orange1)); colors.add((Button) findViewById(R.id.orange2));
        colors.add((Button) findViewById(R.id.orange3)); colors.add((Button) findViewById(R.id.orange4));

        for (Button boton : colors){
            boton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ColorDrawable color = (ColorDrawable) v.getBackground();
                    GradientDrawable drawable = new GradientDrawable();
                    drawable.setShape(GradientDrawable.RECTANGLE);
                    drawable.setStroke(5, Color.YELLOW);
                    drawable.setColor(color.getColor());
                    v.setBackgroundDrawable(drawable);

                    background = String.format("#%06X", (0xFFFFFF & color.getColor()));
                }
            });
        }
    }

    private void buttonSetUpCourse() {
        Button botonSetUpCourse = (Button) findViewById(R.id.set_up_course);
        botonSetUpCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent set_up_course = new Intent(getApplicationContext(), CourseSetUp.class);
                set_up_course.putExtra("NAME", ((EditText) findViewById(R.id.course_name)).getText().toString());
                set_up_course.putExtra("COLOR", background);
                startActivity(set_up_course);
                finish();
            }
        });
    }
}
