package com.example.cristian.unicronos;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

public class CourseSetUp extends AppCompatActivity {
    EditText title1;
    EditText grade1;
    EditText pond1;

    EditText title2;
    EditText grade2;
    EditText pond2;
    Button add2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_course_set_up);
        buttonAddLine();
        buttonAddSection();
        buttonSaveCourse();
    }

    private void buttonAddLine() {
        Button botonSetUpCourse = (Button) findViewById(R.id.grade_add_1);
        botonSetUpCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
            }
        });
    }

    private void buttonAddSection() {
        Button botonSetUpCourse = (Button) findViewById(R.id.section_add);
        botonSetUpCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                pond1 = (EditText) findViewById(R.id.ponderation1_1);

                title2 = (EditText) findViewById(R.id.title_2);
                grade2 = (EditText) findViewById(R.id.grade2_1);
                pond2 = (EditText) findViewById(R.id.ponderation2_1);
                add2 = (Button) findViewById(R.id.grade_add_2);

                /*RelativeLayout rl = (RelativeLayout) findViewById(R.id.scrollView);

                EditText et = new EditText(CourseSetUp.this);
                RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(convertDpToPixels(325, CourseSetUp.this), convertDpToPixels(40, CourseSetUp.this));
                et.setPadding(convertDpToPixels(10, CourseSetUp.this), 0, 0, 0);
                et.setId(R.id.title_2);
                et.setHint("Título (Ej: Certámenes)");
                et.setTextColor(Color.parseColor("#969696"));
                et.setBackgroundResource(R.drawable.text_fields);
                lp.addRule(RelativeLayout.CENTER_HORIZONTAL);
                lp.addRule(RelativeLayout.BELOW, R.id.grade1_1);
                lp.setMargins(0, convertDpToPixels(20, CourseSetUp.this), 0, 0);
                et.setLayoutParams(lp);

                //Falta añadir nota, ponderacion y boton

                Button section_add = (Button) findViewById(R.id.section_add);
                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) section_add.getLayoutParams();
                params.addRule(RelativeLayout.BELOW, R.id.title_2);
                section_add.setLayoutParams(params);

                rl.addView(et);*/

                title2.setVisibility(View.VISIBLE);
                grade2.setVisibility(View.VISIBLE);
                pond2.setVisibility(View.VISIBLE);
                add2.setVisibility(View.VISIBLE);

                RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) pond1.getLayoutParams();
                params.addRule(RelativeLayout.ABOVE, R.id.title_2);
                pond1.setLayoutParams(params);
            }
        });
    }

    private void buttonSaveCourse() {
        Button botonSetUpCourse = (Button) findViewById(R.id.set_up_course);
        botonSetUpCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                title1 = (EditText) findViewById(R.id.title_1);
                grade1 = (EditText) findViewById(R.id.grade1_1);
                pond1 = (EditText) findViewById(R.id.ponderation1_1);

                title2 = (EditText) findViewById(R.id.title_2);
                grade2 = (EditText) findViewById(R.id.grade2_1);
                pond2 = (EditText) findViewById(R.id.ponderation2_1);

                Intent intent = getIntent();
                String string = intent.getStringExtra("NAME")+"/"+intent.getStringExtra("COLOR")+"!"+title1.getText().toString()+"%"+
                        grade1.getText().toString()+"&"+ pond1.getText().toString();

                try {
                    // Creates a file in the primary external storage space of the
                    // current application.
                    // If the file does not exists, it is created.
                    File file = new File(getApplicationContext().getExternalFilesDir(null), "YerkoCuzmar.txt");
                    if (!file.exists())
                        file.createNewFile();

                    // Adds a line to the file
                    BufferedWriter writer = new BufferedWriter(new FileWriter(file, true /*append*/));
                    writer.write(string+"\n");
                    writer.close();
                } catch (IOException e) {
                    Log.e("ReadWriteFile", "Unable to write to the TestFile.txt file.");
                }

                Intent notas2 = new Intent(getApplicationContext(), Notas2.class);
                startActivity(notas2);
                finish();
            }
        });
    }

    public static int convertDpToPixels(float dp, Context context) {
        int px = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, context.getResources().getDisplayMetrics());
        return px;
    }
}
