package com.example.cristian.unicronos;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Registro");
        setContentView(R.layout.activity_register);
        buttonRegistrarse();
        buttonCancelar();
    }

    private void buttonRegistrarse() {
        Button botonRegistrarse = (Button) findViewById(R.id.registrarse);
        botonRegistrarse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                EditText p = (EditText) findViewById(R.id.new_pass);
                EditText p2 = (EditText) findViewById(R.id.new_pass2);

                String pass = p.getText().toString();
                String pass2 = p2.getText().toString();

                if (pass.equals(pass2)){
                    Intent main = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(main);
                    finish();
                }

                else {
                    final Toast toast = Toast.makeText(getApplicationContext(), "Las contraseñas no coinciden", Toast.LENGTH_SHORT);
                    toast.show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 500);
                }

            }
        });
    }

    private void buttonCancelar() {
        Button botonCancelar = (Button) findViewById(R.id.cancelar);
        botonCancelar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent main = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(main);
                finish();
            }
        });
    }
}
