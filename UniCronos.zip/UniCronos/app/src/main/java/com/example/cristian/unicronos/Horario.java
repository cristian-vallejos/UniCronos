package com.example.cristian.unicronos;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.KeyListener;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Horario extends AppCompatActivity {
    private ArrayList<EditText> bloques = new ArrayList<>();
    String usuario, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usuario = getIntent().getStringExtra("nombre_usuario");
        mail = getIntent().getStringExtra("email_usuario");
        setContentView(R.layout.activity_horario);

        //  Bloques de horario
        bloques.add((EditText) findViewById(R.id.textView1)); bloques.add((EditText) findViewById(R.id.textView2));
        bloques.add((EditText) findViewById(R.id.textView3)); bloques.add((EditText) findViewById(R.id.textView4));
        bloques.add((EditText) findViewById(R.id.textView5)); bloques.add((EditText) findViewById(R.id.textView6));
        bloques.add((EditText) findViewById(R.id.textView7)); bloques.add((EditText) findViewById(R.id.textView8));
        bloques.add((EditText) findViewById(R.id.textView9)); bloques.add((EditText) findViewById(R.id.textView10));
        bloques.add((EditText) findViewById(R.id.textView11)); bloques.add((EditText) findViewById(R.id.textView12));
        bloques.add((EditText) findViewById(R.id.textView13)); bloques.add((EditText) findViewById(R.id.textView14));
        bloques.add((EditText) findViewById(R.id.textView15)); bloques.add((EditText) findViewById(R.id.textView16));
        bloques.add((EditText) findViewById(R.id.textView17)); bloques.add((EditText) findViewById(R.id.textView18));
        bloques.add((EditText) findViewById(R.id.textView19)); bloques.add((EditText) findViewById(R.id.textView20));
        bloques.add((EditText) findViewById(R.id.textView21)); bloques.add((EditText) findViewById(R.id.textView22));
        bloques.add((EditText) findViewById(R.id.textView23)); bloques.add((EditText) findViewById(R.id.textView24));
        bloques.add((EditText) findViewById(R.id.textView25)); bloques.add((EditText) findViewById(R.id.textView26));
        bloques.add((EditText) findViewById(R.id.textView27)); bloques.add((EditText) findViewById(R.id.textView28));
        bloques.add((EditText) findViewById(R.id.textView29)); bloques.add((EditText) findViewById(R.id.textView30));
        bloques.add((EditText) findViewById(R.id.textView31)); bloques.add((EditText) findViewById(R.id.textView32));
        bloques.add((EditText) findViewById(R.id.textView33)); bloques.add((EditText) findViewById(R.id.textView34));
        bloques.add((EditText) findViewById(R.id.textView35));

        buttonEdit();
        buttonSetUp();
    }

    private void buttonEdit() {
        Button botonEdit = (Button) findViewById(R.id.edit);
        botonEdit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                for (EditText bloque : bloques){
                    bloque.setFocusableInTouchMode(true);
                    bloque.setEnabled(true);
                }
            }
        });
    }

    private void buttonSetUp() {
        Button botonSetUp = (Button) findViewById(R.id.set_up);
        botonSetUp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent menu = new Intent(getApplicationContext(), Menu.class);
                menu.putExtra("nombre_usuario", usuario);
                menu.putExtra("email_usuario", mail);
                startActivity(menu);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent menu = new Intent(getApplicationContext(), Menu.class);
        menu.putExtra("nombre_usuario", usuario);
        menu.putExtra("email_usuario", mail);
        startActivity(menu);
        finish();
    }
}
