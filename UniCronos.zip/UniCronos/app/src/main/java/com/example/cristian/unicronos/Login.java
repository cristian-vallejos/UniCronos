package com.example.cristian.unicronos;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("Iniciar Sesión");
        setContentView(R.layout.activity_login);
        buttonLogin();
        buttonCancel();

    }

    private void buttonLogin() {
        Button botonLogin = (Button) findViewById(R.id.login);
        botonLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String validUsername = "YerkoCuzmar";
                String validPass = "admin";
                EditText username = (EditText) findViewById(R.id.user);
                EditText password = (EditText) findViewById(R.id.pass);

                String user =  username.getText().toString();
                String pass =  password.getText().toString();

                // El Login se encuentra forzado, por ahora, a una única cuenta.

                if((user.equals(validUsername)) && ((pass.equals(validPass)))){
                    Intent menu = new Intent(getApplicationContext(), Menu.class);
                    menu.putExtra("nombre_usuario", user);
                    startActivity(menu);
                    finish();
                }
                else {
                    final Toast toast = Toast.makeText(getApplicationContext(), "Contraseña incorrecta", Toast.LENGTH_SHORT);
                    toast.show();
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            toast.cancel();
                        }
                    }, 500);
                }

            }
        });
    }

    private void buttonCancel() {
        Button botonCancelar = (Button) findViewById(R.id.cancelar);
        botonCancelar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent main = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(main);
                finish();
            }
        });
    }
}
