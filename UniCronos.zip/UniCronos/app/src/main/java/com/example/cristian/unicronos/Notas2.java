package com.example.cristian.unicronos;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Notas2 extends AppCompatActivity {
    TextView grade_1;
    Button button_1;
    RelativeLayout rl;
    String usuario, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        usuario = getIntent().getStringExtra("nombre_usuario");
        mail = getIntent().getStringExtra("email_usuario");
        setContentView(R.layout.activity_notas2);

        grade_1 = (TextView) findViewById(R.id.grade_1);
        button_1 = (Button) findViewById(R.id.button_1);
        rl = (RelativeLayout) findViewById(R.id.notas2);

        //  Fallo en lectura de archivo. Por ende, se fuerza la inserción.

        grade_1.setText("Física General II");
        grade_1.setBackgroundColor(Color.parseColor("#BA5300"));
        button_1.setVisibility(View.VISIBLE);

        buttonViewCourse();
    }

    private void buttonViewCourse() {
        Button botonViewCourse = (Button) findViewById(R.id.button_1);
        botonViewCourse.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                rl.setVisibility(View.VISIBLE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent menu = new Intent(getApplicationContext(), Menu.class);
        menu.putExtra("nombre_usuario", usuario);
        menu.putExtra("email_usuario", mail);
        startActivity(menu);
        finish();
    }
}
